print("ok")
