namespace SupportDesk.Api.Models;

public class Ticket
{
    public int Id { get; set; }                   // primary key
    public string Title { get; set; } = "";       // required
    public string Description { get; set; } = ""; // required
    public string Status { get; set; } = "Open";  // Open / InProgress / Closed
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public int? CreatedByUserId { get; set; }
    public User? CreatedByUser { get; set; }

    public int? AssignedToUserId { get; set; }
    public User? AssignedToUser { get; set; }

    public ICollection<TicketActivity> Activities { get; set; } = new List<TicketActivity>();
}