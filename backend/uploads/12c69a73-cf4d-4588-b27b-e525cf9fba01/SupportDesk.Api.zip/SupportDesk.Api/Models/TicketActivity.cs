namespace SupportDesk.Api.Models;

public class TicketActivity
{
    public int Id { get; set; }

    public int TicketId { get; set; }
    public Ticket Ticket { get; set; } = null!;

    public string Type { get; set; } = string.Empty; // Created, Updated, StatusChanged, Assigned, CommentAdded

    public string Message { get; set; } = string.Empty;

    public int? PerformedByUserId { get; set; }
    public User? PerformedByUser { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}