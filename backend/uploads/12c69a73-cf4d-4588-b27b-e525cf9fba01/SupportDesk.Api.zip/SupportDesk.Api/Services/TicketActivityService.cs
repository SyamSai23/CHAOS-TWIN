using Microsoft.EntityFrameworkCore;
using SupportDesk.Api.Data;
using SupportDesk.Api.Dtos.Tickets.Activities;

namespace SupportDesk.Api.Services;

public class TicketActivityService : ITicketActivityService
{
    private readonly AppDbContext _db;

    public TicketActivityService(AppDbContext db) => _db = db;

    public async Task<List<TicketActivityResponse>?> GetActivitiesAsync(int ticketId, int callerUserId, string callerRole)
    {
        var isAgentOrAdmin = callerRole == "Agent" || callerRole == "Admin";

        var ticketQuery = _db.Tickets.Where(t => t.Id == ticketId);

        if (!isAgentOrAdmin)
        {
            ticketQuery = ticketQuery.Where(t => t.CreatedByUserId == callerUserId);
        }

        var canAccess = await ticketQuery.AnyAsync();
        if (!canAccess) return null;

        return await _db.TicketActivities
            .Where(a => a.TicketId == ticketId)
            .OrderByDescending(a => a.CreatedAt)
            .Select(a => new TicketActivityResponse
            {
                Id = a.Id,
                TicketId = a.TicketId,
                Type = a.Type,
                Message = a.Message,
                PerformedByUserId = a.PerformedByUserId,
                PerformedByUserEmail = a.PerformedByUser != null ? a.PerformedByUser.Email : null,
                CreatedAt = a.CreatedAt
            })
            .ToListAsync();
    }
}