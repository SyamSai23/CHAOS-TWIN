using SupportDesk.Api.Dtos.Tickets.Activities;

namespace SupportDesk.Api.Services;

public interface ITicketActivityService
{
    Task<List<TicketActivityResponse>?> GetActivitiesAsync(int ticketId, int callerUserId, string callerRole);
}