namespace SupportDesk.Api.Dtos.Tickets.Activities;

public class TicketActivityResponse
{
    public int Id { get; set; }
    public int TicketId { get; set; }
    public string Type { get; set; } = "";
    public string Message { get; set; } = "";
    public int? PerformedByUserId { get; set; }
    public string? PerformedByUserEmail { get; set; }
    public DateTime CreatedAt { get; set; }
}